import { PrismaClient } from '@prisma/client';

// Initialize Prisma
export const prisma = new PrismaClient();
